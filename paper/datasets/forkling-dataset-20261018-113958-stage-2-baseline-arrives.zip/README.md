# forkling dataset

Project: forkling  
Fork: forkling  
Stage: stage-2-baseline-arrives — Baseline arrives: Spoonica enters; A/B starts  
Day: 31 of 365  
Exported: 2026-10-18T11:39:58.399681+00:00

## Contents

- diary.jsonl — every entry the agent wrote about itself
- capabilities.jsonl — SHA-256-chained ledger of demonstrated skills
- graveyard.jsonl — failed patches with prompt-injection excerpts
- ancestry.json — precursor + git generations
- trace.jsonl — SHA-256-chained raw LLM call log
- family.json — federated family registry
- manifest.json — this export's fingerprint
- clock.json — project clock snapshot
